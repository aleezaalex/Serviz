<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

<style>
  body {
    margin: 0; /* Add this line to remove default margin */
}

.Logo{
font-family: 'Inria Serif';
color:white;
}
.Logo1{
font-family: 'Inria Serif';
color:white;
}
@media (min-width: 768px) {
  .Logo1{
    margin-right: 80px;
  }
}

</style>
</head>
<body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<section class="container-fluid"style="background-color:#324897; width:100%;overflow: hidden;position:fixed; top:0;">
<div class="container-fluid d-md-flex flex-column justify-content-center pt-1 mb-4" style="background-color:#324897; width:100%; ">
    <div class="Logo1 align-self-end text-center" style="color: white;">CHRIST</div>
    <div class="Logo align-self-end text-center" style="color: white;">DEEMED TO BE UNIVERSITY</div>
</div>

</section>


</body>
</html>