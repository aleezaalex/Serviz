<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<style>
.Logo1{
font-family: 'Inria Serif';
color:white;
font-size: 20px;
justify-content: center;
}
</style>
</head>
<body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <section style="background-color:#324897;height: 80px; position: fixed; left: 0;bottom: 0;width: 100%; ">
        <div class="container d-md-flex  justify-content-center pt-3">
            <div class="Logo1 align-self-end text-center" style="color: white;">Excellence and Service</div> 
        </div>
    </section>
</body>
</html>