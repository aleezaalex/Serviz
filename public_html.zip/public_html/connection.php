<?php
$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'serviz';

$conn = new mysqli($servername, $username, $password, $dbname);

?>
